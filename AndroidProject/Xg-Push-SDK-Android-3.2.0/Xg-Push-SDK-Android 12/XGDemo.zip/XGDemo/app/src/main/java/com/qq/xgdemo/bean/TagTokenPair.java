package com.qq.xgdemo.bean;

public class TagTokenPair {
    public TagTokenPair(String tag, String token) {
        this.tag = tag;
        this.token = token;
    }

    public String tag;
    public String token;
}