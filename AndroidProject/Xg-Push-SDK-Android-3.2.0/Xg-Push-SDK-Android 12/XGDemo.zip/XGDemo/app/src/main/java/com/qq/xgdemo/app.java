package com.qq.xgdemo;

import android.app.Application;
import android.util.Log;


/**
 * Created by admin on 2017/2/13.
 */

public class app extends Application {
    @Override
    public void onCreate() {
        // TODuto-generated method stub
        super.onCreate();
        Log.d("TPush","APP oncreat");
    }

}



